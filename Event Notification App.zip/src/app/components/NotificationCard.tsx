import { Bell } from 'lucide-react';
import { useNavigate } from 'react-router';

export function NotificationCard() {
  const navigate = useNavigate();

  const handleNotificationClick = () => {
    navigate('/timeline');
  };

  return (
    <div className="relative w-[426px] h-[919px] bg-[#282147] rounded-[50px] border-[5px] border-solid border-white overflow-hidden flex items-center justify-center p-12">
      {/* Notification Card */}
      <button
        onClick={handleNotificationClick}
        className="w-full bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300 hover:scale-105 cursor-pointer"
      >
        <div className="flex items-start gap-6">
          {/* Notification Icon */}
          <div className="w-16 h-16 rounded-full bg-[#B079EF] flex items-center justify-center flex-shrink-0 animate-pulse">
            <Bell className="w-8 h-8 text-white" />
          </div>

          {/* Notification Content */}
          <div className="flex-1 text-left">
            <h2 className="font-['Quicksand:Bold',sans-serif] font-bold text-2xl text-white mb-2">
              Nouveau moment important
            </h2>
            <p className="text-white/80 text-base mb-3">
              Un moment important démarre aujourd'hui
            </p>
            <p className="text-white/60 text-sm">
              Il y a quelques instants
            </p>
          </div>
        </div>

        {/* Pulse indicator */}
        <div className="mt-4 flex justify-end">
          <div className="w-3 h-3 rounded-full bg-[#B079EF]" />
        </div>
      </button>
    </div>
  );
}