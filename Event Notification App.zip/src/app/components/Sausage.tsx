import { Bubble } from './Bubble';

interface SausageProps {
  colors: string[];
  width: 1 | 2 | 3;
  height: number;
  linkNumber?: number;
  startDate: Date;
  endDate: Date;
}

export function Sausage({ colors, width, height, linkNumber }: SausageProps) {
  const widthConfig = {
    1: { width: 30, borderRadius: 15 },
    2: { width: 60, borderRadius: 30 },
    3: { width: 90, borderRadius: 45 }
  };

  const config = widthConfig[width];

  return (
    <div className="relative flex items-start justify-center" style={{ height: `${height}px` }}>
      {/* Sausage body - using exact Figma geometry with background to hide line */}
      <div 
        className="bg-[rgba(255,255,255,0.21)] relative"
        style={{ 
          width: `${config.width}px`,
          height: `${height}px`,
          borderRadius: `${config.borderRadius}px`,
          minHeight: '120px',
          background: 'rgba(255, 255, 255, 0.21)',
          position: 'relative',
          zIndex: 1
        }}
      >
        {/* Bubble info - positioned at the BOTTOM INSIDE the sausage */}
        <Bubble colors={colors} linkNumber={linkNumber} width={width} />
      </div>
    </div>
  );
}