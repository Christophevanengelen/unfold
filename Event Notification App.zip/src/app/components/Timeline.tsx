import { useState, useRef, useEffect } from 'react';
import { Sausage } from './Sausage';
import { X } from 'lucide-react';
import { useNavigate } from 'react-router';

export interface Occurrence {
  id: number;
  age: number; // Age when this occurrence happened
  duration: number; // Duration in years
  colors: string[];
  width: 1 | 2 | 3;
  linkNumber?: number;
}

interface TimelineProps {
  events: Occurrence[];
  initialAge?: number;
}

export function Timeline({ events, initialAge }: TimelineProps) {
  const navigate = useNavigate();
  const contentRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollY, setScrollY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startY, setStartY] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const touchStartRef = useRef(0);
  const currentScrollRef = useRef(0);
  const isScrollingRef = useRef(false);
  const scrollTimeoutRef = useRef<number | null>(null);

  // Constants
  const SCREEN_HEIGHT = 919;
  const PIXELS_PER_YEAR = 365 * 8; // 8 pixels per day * 365 days
  const SPACING_BETWEEN_SAUSAGES = 150;
  const CONTENT_TOP_PADDING = 400;

  // Calculate sausage heights based on duration in years
  const calculateSausageHeight = (durationInYears: number) => {
    const durationInDays = durationInYears * 365;
    return Math.max(120, durationInDays * 8);
  };

  // Calculate positions for each sausage
  const sausagePositions = events.map((event, index) => {
    const height = calculateSausageHeight(event.duration);
    const prevHeights = events.slice(0, index).reduce((sum, e) => {
      return sum + calculateSausageHeight(e.duration) + SPACING_BETWEEN_SAUSAGES;
    }, 0);
    
    return {
      ...event,
      height,
      yPosition: prevHeights,
      bubbleBottomY: prevHeights + height - 50 // Where the bubble center is (at bottom)
    };
  });

  // Get current age based on current sausage
  const getCurrentAge = () => {
    if (events.length === 0) return '0';
    const currentEvent = events[currentIndex];
    return `${currentEvent.age}`;
  };

  // Get numeric age for navigation
  const getCurrentAgeNumber = () => {
    if (events.length === 0) return 0;
    return events[currentIndex].age;
  };

  // Scroll to specific sausage
  const scrollToSausage = (index: number, smooth = true) => {
    if (index < 0 || index >= sausagePositions.length) return;
    
    const targetPosition = sausagePositions[index];
    // Center the bubble vertically on screen
    const screenCenter = SCREEN_HEIGHT / 2;
    const bubbleOffset = 50; // Bubble is 50px from bottom of sausage
    // Calculate absolute position of bubble including padding
    const bubbleAbsoluteY = CONTENT_TOP_PADDING + targetPosition.yPosition + targetPosition.height - bubbleOffset;
    const scrollY = bubbleAbsoluteY - screenCenter;
    
    if (contentRef.current) {
      contentRef.current.style.transition = smooth ? 'transform 1.8s cubic-bezier(0.16, 1, 0.3, 1)' : 'none';
      contentRef.current.style.transform = `translateY(-${scrollY}px)`;
    }
    
    setCurrentIndex(index);
  };

  // Handle wheel scroll with snap
  const handleWheel = (e: WheelEvent) => {
    e.preventDefault();
    
    if (isScrollingRef.current) return;
    
    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }

    const direction = e.deltaY > 0 ? 1 : -1;
    const newIndex = Math.max(0, Math.min(events.length - 1, currentIndex + direction));
    
    if (newIndex !== currentIndex) {
      isScrollingRef.current = true;
      scrollToSausage(newIndex);
      
      scrollTimeoutRef.current = setTimeout(() => {
        isScrollingRef.current = false;
      }, 2000);
    }
  };

  // Touch handling
  const touchStartY = useRef(0);
  const touchStartIndex = useRef(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (contentRef.current) {
      contentRef.current.style.transition = 'none';
    }
    setIsTransitioning(false);
    touchStartY.current = e.touches[0].clientY;
    touchStartIndex.current = currentIndex;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isTransitioning) return;
    
    const deltaY = touchStartY.current - e.touches[0].clientY;
    
    if (Math.abs(deltaY) > 50) {
      const direction = deltaY > 0 ? 1 : -1;
      const newIndex = Math.max(0, Math.min(events.length - 1, touchStartIndex.current + direction));
      
      if (newIndex !== currentIndex) {
        setIsTransitioning(true);
        scrollToSausage(newIndex);
        touchStartIndex.current = newIndex;
        touchStartY.current = e.touches[0].clientY;
        
        setTimeout(() => {
          setIsTransitioning(false);
        }, 2000);
      }
    }
  };

  // Initialize position
  useEffect(() => {
    // If initialAge is provided, find the closest event, otherwise start at index 1
    let startIndex = 1;
    if (initialAge !== undefined && events.length > 0) {
      const foundIndex = events.findIndex(event => event.age >= initialAge);
      startIndex = foundIndex !== -1 ? foundIndex : 1;
    }
    scrollToSausage(Math.min(startIndex, events.length - 1), false);
  }, []);

  // Attach wheel listener
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, [currentIndex, events]);

  return (
    <div 
      ref={containerRef}
      className="relative w-[426px] h-[919px] bg-[#282147] rounded-[50px] border-[5px] border-solid border-white overflow-hidden"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
    >
      {/* Scrollable content */}
      <div 
        ref={contentRef}
        className="absolute left-0 w-full"
      >
        <div className="pt-[400px] pb-[600px]">
          {/* Sausages container - centered */}
          <div className="relative flex justify-center">
            <div className="relative">
              {/* Draw line segments between sausages */}
              {sausagePositions.map((sausage, index) => {
                if (index < sausagePositions.length - 1) {
                  const nextSausage = sausagePositions[index + 1];
                  const lineTop = sausage.yPosition + sausage.height;
                  const lineHeight = nextSausage.yPosition - lineTop;
                  
                  return (
                    <div
                      key={`line-${sausage.id}`}
                      className="absolute left-1/2 -translate-x-1/2 w-[1px] bg-[rgba(255,255,255,0.21)]"
                      style={{
                        top: `${lineTop}px`,
                        height: `${lineHeight}px`
                      }}
                    />
                  );
                }
                return null;
              })}
              
              {sausagePositions.map((sausage) => (
                <div 
                  key={sausage.id}
                  className="absolute left-1/2 -translate-x-1/2"
                  style={{ top: `${sausage.yPosition}px` }}
                >
                  <Sausage
                    colors={sausage.colors}
                    width={sausage.width}
                    height={sausage.height}
                    linkNumber={sausage.linkNumber}
                    startDate={new Date()}
                    endDate={new Date()}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Fixed header with gradient */}
      <div className="absolute top-0 left-0 right-0 pointer-events-none z-10">
        <div className="h-[140px] bg-gradient-to-b from-[#282147] to-[rgba(40,33,71,0)] rounded-t-[50px]" />
        <p className="absolute top-[25px] left-1/2 -translate-x-1/2 font-['Quicksand:Bold',sans-serif] font-bold text-[16px] text-white text-center whitespace-nowrap">
          {getCurrentAge()}
        </p>
        {/* Close button - top right */}
        <button 
          className="absolute top-[25px] right-[25px] w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-white/20 transition-colors pointer-events-auto"
          aria-label="Close"
          onClick={() => navigate(`/overview?age=${getCurrentAgeNumber()}`)}
        >
          <X className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Progress indicator dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 pointer-events-none z-10">
        {events.map((_, index) => (
          <div
            key={index}
            className={`h-2 rounded-full transition-all duration-500 ease-out ${
              index === currentIndex ? 'bg-white w-6' : 'bg-white/30 w-2'
            }`}
          />
        ))}
      </div>
    </div>
  );
}