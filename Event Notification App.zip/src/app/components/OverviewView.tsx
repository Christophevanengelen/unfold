import { useState, useRef, useEffect } from 'react';
import { Sausage } from './Sausage';
import { useSearchParams, useNavigate } from 'react-router';

export interface Occurrence {
  id: number;
  age: number;
  duration: number;
  colors: string[];
  width: 1 | 2 | 3;
  linkNumber?: number;
}

export function OverviewView() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const contentRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const touchStartY = useRef(0);
  const touchStartIndex = useRef(0);
  const isScrollingRef = useRef(false);
  const scrollTimeoutRef = useRef<number | null>(null);

  // Generate events with overlapping ages
  const generateEvents = (): Occurrence[] => {
    const colors = ['#95E1D3', '#F38181', '#B079EF', '#7C98F5', '#AA96DA'];
    const events: Occurrence[] = [];
    
    // Create 30+ events with random start ages between 0-100
    for (let i = 0; i < 80; i++) {
      const numColors = Math.floor(Math.random() * 3) + 1;
      const selectedColors = [];
      for (let j = 0; j < numColors; j++) {
        selectedColors.push(colors[Math.floor(Math.random() * colors.length)]);
      }
      
      const age = Math.random() * 100; // Random age between 0-100
      const duration = 0.1 + Math.random() * 1.2; // shorter durations to fit more
      const width = numColors as 1 | 2 | 3;
      
      events.push({
        id: i + 1,
        age: Math.round(age * 10) / 10,
        duration: Math.round(duration * 10) / 10,
        colors: selectedColors,
        width,
        linkNumber: Math.random() > 0.7 ? Math.floor(Math.random() * 5) + 1 : undefined
      });
    }

    // Sort by age descending (like Timeline)
    return events.sort((a, b) => b.age - a.age);
  };

  const [events] = useState(() => generateEvents());

  // Constants
  const SCREEN_HEIGHT = 919;
  const PIXELS_PER_YEAR = 365 * 8;
  const CONTENT_TOP_PADDING = 400;
  const COLLISION_PADDING = 20; // minimum gap between sausages in pixels

  // Calculate sausage heights
  const calculateSausageHeight = (durationInYears: number) => {
    const durationInDays = durationInYears * 365;
    return Math.max(120, durationInDays * 8);
  };

  // Position sausages in columns with SIDE-BY-SIDE layout
  interface PositionedSausage extends Occurrence {
    height: number;
    yPosition: number;
    column: number;
  }

  // Dedicated horizontal slots per width type (thin left, thick right)
  // Thin (30px wide): 3 slots
  // Medium (60px wide): 2 slots
  // Thick (90px wide): 2 slots
  // Layout calculated so NO horizontal overlap between any slots:
  // Thin edges:  5-35, 39-69, 73-103
  // Medium edges: 108-168, 172-232
  // Thick edges:  237-327, 331-421
  const SLOTS: Record<number, number[]> = {
    1: [20, 54, 88],         // 3 thin slots on the left
    2: [138, 202],           // 2 medium slots in the center
    3: [282, 376],           // 2 thick slots on the right
  };

  const positionSausages = (): PositionedSausage[] => {
    const positioned: PositionedSausage[] = [];
    
    // Track occupied vertical ranges per slot (keyed by "width-slotIndex")
    const slotOccupied: Record<string, Array<[number, number]>> = {};

    // Sort events by age descending for consistent placement
    const sortedEvents = [...events].sort((a, b) => b.age - a.age);

    sortedEvents.forEach((event) => {
      const height = calculateSausageHeight(event.duration);
      const yPosition = (100 - event.age) * PIXELS_PER_YEAR;
      const yStart = yPosition;
      const yEnd = yPosition + height;

      const slots = SLOTS[event.width] || SLOTS[1];
      let placed = false;

      for (let si = 0; si < slots.length; si++) {
        const key = `${event.width}-${si}`;
        if (!slotOccupied[key]) slotOccupied[key] = [];

        const overlaps = slotOccupied[key].some(([occStart, occEnd]) => {
          return yStart < occEnd + COLLISION_PADDING && yEnd > occStart - COLLISION_PADDING;
        });

        if (!overlaps) {
          positioned.push({
            ...event,
            height,
            yPosition,
            column: si, // store slot index, we'll use SLOTS to get x
          });
          slotOccupied[key].push([yStart, yEnd]);
          placed = true;
          break;
        }
      }
      // If no slot available, skip this event
    });

    return positioned;
  };

  const sausagePositions = positionSausages();

  // Sort positioned sausages by yPosition for sequential navigation
  const sortedPositions = [...sausagePositions].sort((a, b) => a.yPosition - b.yPosition);

  // Get current age
  const getCurrentAge = () => {
    if (sortedPositions.length === 0) return '0';
    return `${sortedPositions[currentIndex]?.age ?? 0}`;
  };

  // Scroll to sausage - SAME AS TIMELINE
  const scrollToSausage = (index: number, smooth = true) => {
    if (index < 0 || index >= sortedPositions.length) return;
    
    const targetPosition = sortedPositions[index];
    const screenCenter = SCREEN_HEIGHT / 2;
    const bubbleOffset = 50;
    const bubbleAbsoluteY = CONTENT_TOP_PADDING + targetPosition.yPosition + targetPosition.height - bubbleOffset;
    const scrollY = bubbleAbsoluteY - screenCenter;
    
    if (contentRef.current) {
      contentRef.current.style.transition = smooth ? 'transform 1.8s cubic-bezier(0.16, 1, 0.3, 1)' : 'none';
      contentRef.current.style.transform = `translateY(-${scrollY}px)`;
    }
    
    setCurrentIndex(index);
  };

  // Touch handling - EXACTLY SAME AS TIMELINE
  const handleTouchStart = (e: React.TouchEvent) => {
    if (contentRef.current) {
      contentRef.current.style.transition = 'none';
    }
    setIsTransitioning(false);
    touchStartY.current = e.touches[0].clientY;
    touchStartIndex.current = currentIndex;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isTransitioning) return;
    
    const deltaY = touchStartY.current - e.touches[0].clientY;
    
    if (Math.abs(deltaY) > 50) {
      const direction = deltaY > 0 ? 1 : -1;
      const newIndex = Math.max(0, Math.min(sortedPositions.length - 1, touchStartIndex.current + direction));
      
      if (newIndex !== currentIndex) {
        setIsTransitioning(true);
        scrollToSausage(newIndex);
        touchStartIndex.current = newIndex;
        touchStartY.current = e.touches[0].clientY;
        
        setTimeout(() => {
          setIsTransitioning(false);
        }, 2000);
      }
    }
  };

  // Wheel handling - EXACTLY SAME AS TIMELINE
  const handleWheel = (e: WheelEvent) => {
    e.preventDefault();
    
    if (isScrollingRef.current) return;
    
    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }

    const direction = e.deltaY > 0 ? 1 : -1;
    const newIndex = Math.max(0, Math.min(sortedPositions.length - 1, currentIndex + direction));
    
    if (newIndex !== currentIndex) {
      isScrollingRef.current = true;
      scrollToSausage(newIndex);
      
      scrollTimeoutRef.current = setTimeout(() => {
        isScrollingRef.current = false;
      }, 2000) as unknown as number;
    }
  };

  // Initialize with age from URL
  useEffect(() => {
    const ageParam = searchParams.get('age');
    let startIndex = 1;
    if (ageParam && sortedPositions.length > 0) {
      const initialAge = parseInt(ageParam);
      const foundIndex = sortedPositions.findIndex(event => event.age >= initialAge);
      startIndex = foundIndex !== -1 ? foundIndex : 1;
    }
    scrollToSausage(Math.min(startIndex, sortedPositions.length - 1), false);
  }, []);

  // Attach wheel listener
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, [currentIndex, events]);

  // Handle clicking on a sausage
  const handleSausageClick = (age: number) => {
    navigate(`/timeline?age=${Math.floor(age)}`);
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-[426px] h-[919px] bg-[#282147] rounded-[50px] border-[5px] border-solid border-white overflow-hidden"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
    >
      {/* Scrollable content */}
      <div 
        ref={contentRef}
        className="absolute left-0 w-full"
      >
        <div className="pt-[400px] pb-[600px]">
          {/* Sausages positioned side-by-side in columns */}
          <div className="relative">
            {sausagePositions.map((sausage) => (
              <div 
                key={sausage.id}
                className="absolute cursor-pointer hover:opacity-80 transition-opacity"
                style={{
                  top: `${sausage.yPosition}px`,
                  left: `${SLOTS[sausage.width][sausage.column]}px`,
                  transform: 'translateX(-50%)'
                }}
                onClick={() => handleSausageClick(sausage.age)}
              >
                <Sausage
                  colors={sausage.colors}
                  width={sausage.width}
                  height={sausage.height}
                  linkNumber={sausage.linkNumber}
                  startDate={new Date()}
                  endDate={new Date()}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Fixed header with gradient */}
      <div className="absolute top-0 left-0 right-0 pointer-events-none z-10">
        <div className="h-[140px] bg-gradient-to-b from-[#282147] to-[rgba(40,33,71,0)] rounded-t-[50px]" />
        <p className="absolute top-[25px] left-1/2 -translate-x-1/2 font-['Quicksand:Bold',sans-serif] font-bold text-[16px] text-white text-center whitespace-nowrap">
          {getCurrentAge()}
        </p>
      </div>

      {/* Fixed footer gradient */}
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none z-10">
        <div className="h-[140px] bg-gradient-to-t from-[#282147] to-[rgba(40,33,71,0)] rounded-b-[50px]" />
      </div>
    </div>
  );
}