interface BubbleProps {
  colors: string[];
  linkNumber?: number;
  width: 1 | 2 | 3;
}

export function Bubble({ colors, linkNumber, width }: BubbleProps) {
  // Exact Figma spacing specifications
  const circleSpacing = 20; // 20px apart (center to center)
  const circleDiameter = 15; // 15px diameter (7.5px radius)
  
  // Bottom padding matches border radius for each width (from Figma examples)
  const bottomPaddingMap = {
    1: 15,   // 15px for thin (matches border radius)
    2: 30,   // 30px for medium (matches border radius)
    3: 45    // 45px for thick (matches border radius)
  };
  
  const bottomPadding = bottomPaddingMap[width];
  
  // Top padding varies by width: borderRadius + 0.394
  const borderRadiusMap = {
    1: 15,
    2: 30,
    3: 45
  };
  
  const borderRadius = borderRadiusMap[width];
  const topPaddingToFirstCircle = borderRadius + 0.394;
  
  return (
    <div 
      className="absolute bottom-0 left-0 right-0 flex flex-col items-center"
      style={{
        paddingBottom: `${bottomPadding - circleDiameter / 2}px` // Adjust for circle radius
      }}
    >
      {/* Link number - shows if this event is part of a recurring series */}
      {linkNumber && (
        <p className="font-['Quicksand:Bold',sans-serif] font-bold text-white leading-none mb-4 text-[24px]">
          {linkNumber}
        </p>
      )}
      
      {/* Color circles - positioned with exact Figma spacing */}
      <div className="flex flex-col-reverse items-center" style={{ gap: `${circleSpacing - circleDiameter}px` }}>
        {colors.map((color, index) => (
          <div
            key={index}
            className="rounded-full"
            style={{ 
              backgroundColor: color,
              width: `${circleDiameter}px`,
              height: `${circleDiameter}px`
            }}
          />
        ))}
      </div>
    </div>
  );
}