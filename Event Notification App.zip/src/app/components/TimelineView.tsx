import { useState } from 'react';
import { Timeline, Occurrence } from './Timeline';
import { useSearchParams } from 'react-router';

// Mock API response data with ages and durations in years
const mockEvents: Occurrence[] = [
  {
    id: 1,
    age: 30,
    duration: 0.5, // 6 months
    colors: ['#B079EF', '#7C98F5', '#95E1D3'],
    width: 3,
    linkNumber: 3
  },
  {
    id: 2,
    age: 27,
    duration: 3, // 3 years
    colors: ['#B079EF', '#7C98F5', '#95E1D3'],
    width: 3,
    linkNumber: 2
  },
  {
    id: 3,
    age: 25,
    duration: 2, // 2 years
    colors: ['#B079EF', '#7C98F5', '#95E1D3'],
    width: 3,
    linkNumber: 1
  }
];

export function TimelineView() {
  const [events] = useState(mockEvents);
  const [searchParams] = useSearchParams();
  const initialAge = searchParams.get('age');

  return <Timeline events={events} initialAge={initialAge ? parseInt(initialAge) : undefined} />;
}