import { createBrowserRouter } from "react-router";
import { NotificationCard } from "./components/NotificationCard";
import { TimelineView } from "./components/TimelineView";
import { OverviewView } from "./components/OverviewView";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: NotificationCard,
  },
  {
    path: "/overview",
    Component: OverviewView,
  },
  {
    path: "/timeline",
    Component: TimelineView,
  },
]);