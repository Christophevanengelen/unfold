import svgPaths from "./svg-zvy9zzimaj";

function Group() {
  return (
    <div className="absolute contents left-[178.35px] top-[-2665.6px]">
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[673.969px] left-[178.35px] rounded-[200px] top-[-2665.6px] w-[79.112px]" />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[178.35px] top-[-2665.6px]">
      <Group />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[191.42px] top-[-2647.86px]">
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[134.04px] left-[191.42px] rounded-[200px] top-[-2647.86px] w-[52.967px]" />
      <div className="absolute left-[206.39px] size-[23.017px] top-[-2590.85px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #B079EF)" id="Ellipse 620" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[206.39px] size-[23.017px] top-[-2553.17px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #7C98F5)" id="Ellipse 621" r="11.5085" />
        </svg>
      </div>
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[217.4px] text-[32px] text-center text-white top-[-2638.89px] whitespace-nowrap">3</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[178.32px] top-[-2665.6px]">
      <Group1 />
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[673.969px] left-[178.32px] rounded-[200px] top-[1485.3px] w-[79.112px]" />
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[1993.75px] left-[178.35px] rounded-[200px] top-[-1470.52px] w-[79.112px]" />
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[134.04px] left-[191.42px] rounded-[200px] top-[374.66px] w-[52.967px]" />
      <div className="absolute left-[206.39px] size-[23.017px] top-[431.68px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #B079EF)" id="Ellipse 620" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[206.39px] size-[23.017px] top-[469.35px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #7C98F5)" id="Ellipse 621" r="11.5085" />
        </svg>
      </div>
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[217.9px] text-[32px] text-center text-white top-[383.63px] whitespace-nowrap">2</p>
      <div className="absolute flex h-[521.108px] items-center justify-center left-[217.9px] top-[-1991.63px] w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "18" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[521.108px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 521.108 1">
                <line id="Line 15" stroke="var(--stroke-0, white)" strokeOpacity="0.21" x2="521.108" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[961.925px] items-center justify-center left-[217.88px] top-[523.38px] w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "18" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[961.925px]">
            <div className="absolute inset-[-0.5px_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 961.925 1">
                <path d={svgPaths.p38826180} id="Line 16" stroke="var(--stroke-0, white)" strokeOpacity="0.21" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[134.04px] left-[191.39px] rounded-[200px] top-[2009.69px] w-[52.967px]" />
      <div className="absolute left-[206.37px] size-[23.017px] top-[2066.71px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #B079EF)" id="Ellipse 620" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[206.37px] size-[23.017px] top-[2104.38px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #7C98F5)" id="Ellipse 621" r="11.5085" />
        </svg>
      </div>
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[217.88px] text-[32px] text-center text-white top-[2018.66px] whitespace-nowrap">1</p>
      <Group2 />
    </div>
  );
}

function TimlineMoving() {
  return (
    <div className="absolute contents left-[178.32px] top-[-2665.6px]" data-name="timline moving">
      <Group3 />
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[315.03px] text-[16px] text-center text-white top-[431.74px] w-[209.751px]">28/01/2026</p>
    </div>
  );
}

function ZoneFixe() {
  return (
    <div className="absolute contents left-[4.99px] top-[4.52px]" data-name="zone fixe">
      <div className="absolute flex h-[139.51px] items-center justify-center left-[4.99px] top-[4.52px] w-[415.756px]">
        <div className="flex-none rotate-180">
          <div className="bg-gradient-to-t from-[#282147] h-[139.51px] rounded-[50px] to-[97.147%] to-[rgba(40,33,71,0)] w-[415.756px]" />
        </div>
      </div>
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[219.35px] text-[16px] text-center text-white top-[19.71px] w-[209.751px]">01/2026</p>
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full">
      <div className="absolute bg-[#282147] border-5 border-solid border-white h-[919.234px] left-0 rounded-[50px] top-0 w-[426.09px]" />
      <TimlineMoving />
      <ZoneFixe />
    </div>
  );
}