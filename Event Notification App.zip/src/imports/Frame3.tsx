function Group() {
  return (
    <div className="absolute contents left-[13.07px] top-[447.76px]">
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[134.04px] left-[13.07px] rounded-[200px] top-[447.76px] w-[52.967px]" />
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[39.56px] text-[32px] text-center text-white top-[456.73px] whitespace-nowrap">2</p>
      <div className="absolute left-[28.05px] size-[23.017px] top-[504.78px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #B079EF)" id="Ellipse 620" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[28.05px] size-[23.017px] top-[542.45px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #7C98F5)" id="Ellipse 621" r="11.5085" />
        </svg>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-0 top-0">
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[596.328px] left-0 rounded-[200px] top-0 w-[79.112px]" />
      <Group />
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full">
      <Group1 />
    </div>
  );
}