function Group2() {
  return (
    <div className="h-[598.691px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 598.691">
        <g id="Group 21279">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="596.224" id="Rectangle 2007" rx="14.5406" width="29.0813" y="2.46774" />
          <circle cx="14.5406" cy="11.5085" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5406" cy="44.7867" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5406" cy="78.0649" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group3() {
  return (
    <div className="h-[417.901px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 417.901">
        <g id="Group 21280">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="417.901" id="Rectangle 2007" rx="14.5406" width="29.0813" x="1.52588e-05" y="9.94324e-05" />
          <circle cx="14.5407" cy="14.4617" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5407" cy="47.74" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5407" cy="81.0182" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group5() {
  return (
    <div className="h-[583.577px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 583.577">
        <g id="Group 21282">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="583.577" id="Rectangle 2007" rx="14.5406" width="29.0813" x="1.27896e-05" y="9.94324e-05" />
          <circle cx="14.5405" cy="14.4617" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5405" cy="47.74" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5405" cy="81.0182" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group6() {
  return (
    <div className="h-[477.435px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 477.435">
        <g id="Group 21283">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="477.435" id="Rectangle 2007" rx="14.5406" width="29.0813" y="0.000104427" />
          <circle cx="14.5406" cy="14.4617" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5406" cy="42.3191" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5406" cy="75.5973" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group7() {
  return (
    <div className="h-[553.223px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 553.224">
        <g id="Group 21284">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="550.756" id="Rectangle 2007" rx="14.5406" width="29.0813" y="2.46774" />
          <circle cx="14.5405" cy="11.5085" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5405" cy="44.7867" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5405" cy="78.0649" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group13() {
  return (
    <div className="h-[730.876px] relative w-[52.967px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52.9665 730.877">
        <g id="Group 21296">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="730.876" id="Rectangle 2006" rx="26.4833" width="52.9665" y="0.000104374" />
          <circle cx="26.4831" cy="24.8676" fill="var(--fill-0, #AAD681)" id="Ellipse 613" r="11.5085" />
          <circle cx="26.4832" cy="67.9651" fill="var(--fill-0, #DF64B8)" id="Ellipse 614" r="11.5085" />
          <circle cx="26.4832" cy="105.641" fill="var(--fill-0, #E37470)" id="Ellipse 615" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[256.81px] top-[281.15px]">
      <div className="absolute flex h-[730.876px] items-center justify-center left-[256.81px] top-[281.15px] w-[52.967px]">
        <div className="flex-none rotate-180">
          <Group13 />
        </div>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[19.19px] top-[-333.29px]">
      <div className="absolute flex h-[598.691px] items-center justify-center left-[209.29px] top-[783.87px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group2 />
        </div>
      </div>
      <div className="absolute flex h-[417.901px] items-center justify-center left-[161.76px] top-[48.3px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group3 />
        </div>
      </div>
      <div className="absolute flex h-[583.577px] items-center justify-center left-[114.24px] top-[200.29px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group5 />
        </div>
      </div>
      <div className="absolute flex h-[477.435px] items-center justify-center left-[66.71px] top-[-333.29px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group6 />
        </div>
      </div>
      <div className="absolute flex h-[553.223px] items-center justify-center left-[19.19px] top-[600.56px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group7 />
        </div>
      </div>
      <Group1 />
    </div>
  );
}

function Group9() {
  return (
    <div className="h-[596.224px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 596.224">
        <g id="Group 21279">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="596.224" id="Rectangle 2007" rx="14.5406" width="29.0813" x="2.31619e-05" />
          <circle cx="14.5406" cy="14.4616" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5406" cy="47.7399" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5406" cy="81.0181" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group10() {
  return (
    <div className="h-[417.901px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 417.902">
        <g id="Group 21280">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="417.901" id="Rectangle 2007" rx="14.5406" width="29.0813" x="1.91843e-05" />
          <circle cx="14.5407" cy="14.4616" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5407" cy="47.7399" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5407" cy="81.0181" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group11() {
  return (
    <div className="h-[583.577px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 583.577">
        <g id="Group 21282">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="583.577" id="Rectangle 2007" rx="14.5406" width="29.0813" x="1.27896e-05" />
          <circle cx="14.5405" cy="14.4616" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5405" cy="47.7399" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5405" cy="81.0181" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group12() {
  return (
    <div className="h-[477.435px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 477.435">
        <g id="Group 21283">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="477.435" id="Rectangle 2007" rx="14.5406" width="29.0813" x="6.39478e-06" />
          <circle cx="14.5406" cy="14.4616" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5406" cy="47.7399" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5406" cy="81.0181" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[66.71px] top-[-1432.51px]">
      <div className="absolute flex h-[596.224px] items-center justify-center left-[209.29px] top-[-608.21px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group9 />
        </div>
      </div>
      <div className="absolute flex h-[417.901px] items-center justify-center left-[66.71px] top-[-1114.84px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group10 />
        </div>
      </div>
      <div className="absolute flex h-[583.577px] items-center justify-center left-[114.24px] top-[-1432.51px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group11 />
        </div>
      </div>
      <div className="absolute flex h-[477.435px] items-center justify-center left-[161.76px] top-[-1085.65px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group12 />
        </div>
      </div>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[19.19px] top-[-1432.51px]">
      <Group />
      <Group4 />
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full">
      <div className="absolute bg-[#282147] border-5 border-solid border-white h-[919.234px] left-0 rounded-[50px] top-0 w-[426.09px]" />
      <Group8 />
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[673.969px] left-[328.23px] rounded-[200px] top-[1670.4px] w-[79.112px]" />
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[641.903px] left-[328.23px] rounded-[200px] top-[-111.3px] w-[79.112px]" />
      <div className="absolute left-[356.27px] size-[23.017px] top-[439.05px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #B079EF)" id="Ellipse 620" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[356.27px] size-[23.017px] top-[476.73px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #7C98F5)" id="Ellipse 621" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[356.27px] size-[23.017px] top-[2251.8px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #B079EF)" id="Ellipse 620" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[356.27px] size-[23.017px] top-[2289.47px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #7C98F5)" id="Ellipse 621" r="11.5085" />
        </svg>
      </div>
      <div className="absolute flex h-[134.87px] items-center justify-center left-[4.99px] top-[4.64px] w-[416.202px]">
        <div className="flex-none rotate-180">
          <div className="bg-gradient-to-t from-[#282147] h-[134.87px] rounded-[50px] to-[97.147%] to-[rgba(40,33,71,0)] w-[416.202px]" />
        </div>
      </div>
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[220.8px] text-[16px] text-center text-white top-[30.01px] w-[209.751px]">01/2026</p>
    </div>
  );
}