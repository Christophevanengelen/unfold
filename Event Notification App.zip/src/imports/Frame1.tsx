function Group1() {
  return (
    <div className="h-[1135.239px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 1135.24">
        <g id="Group 21280">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="1135.24" id="Rectangle 2007" rx="14.5406" width="29.0813" x="1.52588e-05" />
          <circle cx="14.5407" cy="14.4616" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5407" cy="47.7399" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5407" cy="81.0181" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="h-[1175.191px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 1175.19">
        <g id="Group 21282">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="1175.19" id="Rectangle 2007" rx="14.5406" width="29.0813" x="1.27896e-05" />
          <circle cx="14.5405" cy="14.4616" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5405" cy="47.7399" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5405" cy="81.0181" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group3() {
  return (
    <div className="h-[477.435px] relative w-[29.081px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.0813 477.435">
        <g id="Group 21283">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="477.435" id="Rectangle 2007" rx="14.5406" width="29.0813" x="6.39478e-06" />
          <circle cx="14.5406" cy="14.4616" fill="var(--fill-0, #E37470)" id="Ellipse 618" r="11.5085" />
          <circle cx="14.5406" cy="47.7399" fill="var(--fill-0, #FED857)" id="Ellipse 619" r="11.5085" />
          <circle cx="14.5406" cy="81.0181" fill="var(--fill-0, #7AE0D9)" id="Ellipse 620" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group4() {
  return (
    <div className="h-[730.876px] relative w-[52.967px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52.9665 730.876">
        <g id="Group 21296">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="730.876" id="Rectangle 2006" rx="26.4833" width="52.9665" />
          <circle cx="26.4832" cy="30.2887" fill="var(--fill-0, #AAD681)" id="Ellipse 613" r="11.5085" />
          <circle cx="26.4832" cy="67.965" fill="var(--fill-0, #DF64B8)" id="Ellipse 614" r="11.5085" />
          <circle cx="26.4832" cy="105.641" fill="var(--fill-0, #E37470)" id="Ellipse 615" r="11.5085" />
        </g>
      </svg>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[256.81px] top-[281.15px]">
      <div className="absolute flex h-[730.876px] items-center justify-center left-[256.81px] top-[281.15px] w-[52.967px]">
        <div className="flex-none rotate-180">
          <Group4 />
        </div>
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[4.7px] top-[-669.04px]">
      <div className="absolute flex h-[1135.239px] items-center justify-center left-[161.76px] top-[-669.04px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group1 />
        </div>
      </div>
      <div className="absolute flex h-[1175.191px] items-center justify-center left-[114.24px] top-[-391.32px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group2 />
        </div>
      </div>
      <div className="absolute flex h-[477.435px] items-center justify-center left-[66.71px] top-[-333.29px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <Group3 />
        </div>
      </div>
      <Group />
      <div className="absolute flex h-[596.224px] items-center justify-center left-[209.29px] top-[-613.63px] w-[29.081px]">
        <div className="flex-none rotate-180">
          <div className="bg-[rgba(255,255,255,0.21)] h-[596.224px] rounded-[200px] w-[29.081px]" />
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[212.32px] size-[23.017px] top-[-43.38px]">
        <div className="flex-none rotate-180">
          <div className="relative size-[23.017px]">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
              <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #E37470)" id="Ellipse 625" r="11.5085" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute flex items-center justify-center left-[212.32px] size-[23.017px] top-[-76.66px]">
        <div className="flex-none rotate-180">
          <div className="relative size-[23.017px]">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
              <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #FED857)" id="Ellipse 626" r="11.5085" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[641.903px] left-[328.22px] rounded-[200px] top-[61.15px] w-[79.112px]" />
      <div className="absolute bg-[rgba(255,255,255,0.21)] h-[134.04px] left-[341.3px] rounded-[200px] top-[554.48px] w-[52.967px]" />
      <div className="absolute left-[356.27px] size-[23.017px] top-[611.5px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #B079EF)" id="Ellipse 620" r="11.5085" />
        </svg>
      </div>
      <div className="absolute left-[356.27px] size-[23.017px] top-[649.17px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.017 23.017">
          <circle cx="11.5085" cy="11.5085" fill="var(--fill-0, #7C98F5)" id="Ellipse 621" r="11.5085" />
        </svg>
      </div>
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[367.78px] text-[32px] text-center text-white top-[563.45px] whitespace-nowrap">2</p>
      <div className="absolute flex h-[521.108px] items-center justify-center left-[367.78px] top-[-459.96px] w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "18" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[521.108px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 521.108 1">
                <line id="Line 15" stroke="var(--stroke-0, white)" strokeOpacity="0.21" x2="521.108" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[961.925px] items-center justify-center left-[367.78px] top-[703.05px] w-0" style={{ "--transform-inner-width": "1200", "--transform-inner-height": "18" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[961.925px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 961.925 1">
                <line id="Line 20" stroke="var(--stroke-0, white)" strokeOpacity="0.21" x2="961.925" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[139.51px] items-center justify-center left-[4.7px] top-[4.88px] w-[416.078px]">
        <div className="flex-none rotate-180">
          <div className="bg-gradient-to-t from-[#282147] h-[139.51px] rounded-[50px] to-[97.147%] to-[rgba(40,33,71,0)] w-[416.078px]" />
        </div>
      </div>
      <p className="-translate-x-1/2 absolute font-['Quicksand:Bold',sans-serif] font-bold leading-[normal] left-[220.8px] text-[16px] text-center text-white top-[24.59px] w-[209.751px]">01/2026</p>
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full">
      <div className="absolute bg-[#282147] border-5 border-solid border-white h-[919.234px] left-0 rounded-[50px] top-0 w-[426.09px]" />
      <Group5 />
    </div>
  );
}