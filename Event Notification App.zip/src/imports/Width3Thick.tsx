export default function Width3Thick() {
  return (
    <div className="relative size-full" data-name="Width 3 (Thick)">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 90 445.961">
        <g clipPath="url(#clip0_9_71)" id="Width 3 (Thick)">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="445.961" id="saucage time" rx="45" width="90" />
          <circle cx="45" cy="400.809" fill="var(--fill-0, white)" id="Ellipse 644" r="7.5" />
          <circle cx="45" cy="380.809" fill="var(--fill-0, white)" id="Ellipse 645" r="7.5" />
          <circle cx="45" cy="360.809" fill="var(--fill-0, white)" id="Ellipse 646" r="7.5" />
        </g>
        <defs>
          <clipPath id="clip0_9_71">
            <rect fill="white" height="445.961" width="90" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}