export default function Width1Thin() {
  return (
    <div className="relative size-full" data-name="Width 1 (Thin)">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 445.961">
        <g clipPath="url(#clip0_9_59)" id="Width 1 (Thin)">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="445.961" id="saucage time" rx="15" width="30" />
          <circle cx="15" cy="430.567" fill="var(--fill-0, white)" id="Ellipse 630" r="7.5" />
          <circle cx="15" cy="410.567" fill="var(--fill-0, white)" id="Ellipse 631" r="7.5" />
          <circle cx="15" cy="390.567" fill="var(--fill-0, white)" id="Ellipse 632" r="7.5" />
        </g>
        <defs>
          <clipPath id="clip0_9_59">
            <rect fill="white" height="445.961" width="30" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}