export default function Width2Medium() {
  return (
    <div className="relative size-full" data-name="Width 2 (Medium)">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 445.961">
        <g clipPath="url(#clip0_9_65)" id="Width 2 (Medium)">
          <rect fill="var(--fill-0, white)" fillOpacity="0.21" height="445.961" id="saucage time" rx="30" width="60" />
          <circle cx="30" cy="416.103" fill="var(--fill-0, white)" id="Ellipse 637" r="7.5" />
          <circle cx="30" cy="396.103" fill="var(--fill-0, white)" id="Ellipse 638" r="7.5" />
          <circle cx="30" cy="376.103" fill="var(--fill-0, white)" id="Ellipse 639" r="7.5" />
        </g>
        <defs>
          <clipPath id="clip0_9_65">
            <rect fill="white" height="445.961" width="60" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}