
  # Event Notification App

  This is a code bundle for Event Notification App. The original project is available at https://www.figma.com/design/NzrdPgsFVoFZRYNCE4TD96/Event-Notification-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  